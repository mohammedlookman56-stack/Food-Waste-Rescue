FOOD WASTE RESCUE — itch.io build

Upload: food_waste_rescue_itch.zip
The ZIP contains index.html at its root.

Recommended itch.io settings:
- Project type: HTML
- Upload the ZIP as the HTML game build
- Enable "This file will be played in the browser"
- Suggested viewport: 1280 x 720
- Mobile friendly: Yes

No external assets are required; the game uses inline CSS/JavaScript and procedural Web Audio.
